/**
 * 
 */
package com.webmethods.caf.appletportlet;

/**
 * @author gsadmin
 *
 */

import javax.portlet.PortletPreferences;

public class AppletPortlet  extends   com.webmethods.caf.faces.bean.BaseFacesPreferencesBean {

	public static final String[] PREFERENCES_NAMES = new String[] {};
	private com.webmethods.caf.AppletPortletApp appletPortletApp = null;
	private static final String[][] LOADAPPLET_PROPERTY_BINDINGS = new String[][] {
	};
	
	/**
	 * Create new preferences bean with list of preference names
	 */
	public AppletPortlet() {
		super(PREFERENCES_NAMES);
	}
	
	/**
	 * Call this method in order to persist
	 * Portlet preferences
	 */
	public void storePreferences() throws Exception {
		updatePreferences();
		PortletPreferences preferences = getPreferences();
		preferences.store();
	}

	public com.webmethods.caf.AppletPortletApp getAppletPortletApp()  {
		if (appletPortletApp == null) {
		    appletPortletApp = (com.webmethods.caf.AppletPortletApp)resolveExpression("#{AppletPortletApp}");
		}
		return appletPortletApp;
	}

	public String loadApplet() {
	    // TODO: implement java method
	    
		return OUTCOME_OK;
	}
}
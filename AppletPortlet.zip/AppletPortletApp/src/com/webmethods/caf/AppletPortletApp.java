/**
 * 
 */
package com.webmethods.caf;

/**
 * @author gsadmin
 *
 */
public class AppletPortletApp extends com.webmethods.caf.faces.bean.BaseApplicationBean 
{
	public AppletPortletApp()
	{
		super();
		setCategoryName( "CafApplication" );
		setSubCategoryName( "AppletPortletApp" );
	}
}